<?php
require __DIR__ . '/config.php';
require_role('admin');
$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT p.*, u.full_name, u.username, s.student_no, s.class_level, fc.name AS category, verifier.full_name AS verifier_name FROM payments p JOIN students s ON s.id = p.student_id JOIN users u ON u.id = s.user_id JOIN fee_categories fc ON fc.id = p.fee_category_id LEFT JOIN users verifier ON verifier.id = p.verified_by WHERE p.id = ?");
$stmt->execute([$id]);
$payment = $stmt->fetch();
if (!$payment) { http_response_code(404); exit('Transaksi tidak ditemukan.'); }
$pageTitle = 'Kwitansi Transaksi';
function angkaTerbilang(int $angka): string
{
    $kata = ['', 'satu', 'dua', 'tiga', 'empat', 'lima', 'enam', 'tujuh', 'delapan', 'sembilan', 'sepuluh', 'sebelas'];
    if ($angka < 12) return $kata[$angka];
    if ($angka < 20) return angkaTerbilang($angka - 10) . ' belas';
    if ($angka < 100) return angkaTerbilang(intdiv($angka, 10)) . ' puluh ' . angkaTerbilang($angka % 10);
    if ($angka < 200) return 'seratus ' . angkaTerbilang($angka - 100);
    if ($angka < 1000) return angkaTerbilang(intdiv($angka, 100)) . ' ratus ' . angkaTerbilang($angka % 100);
    if ($angka < 2000) return 'seribu ' . angkaTerbilang($angka - 1000);
    if ($angka < 1000000) return angkaTerbilang(intdiv($angka, 1000)) . ' ribu ' . angkaTerbilang($angka % 1000);
    if ($angka < 1000000000) return angkaTerbilang(intdiv($angka, 1000000)) . ' juta ' . angkaTerbilang($angka % 1000000);
    if ($angka < 1000000000000) return angkaTerbilang(intdiv($angka, 1000000000)) . ' miliar ' . angkaTerbilang($angka % 1000000000);
    return (string)$angka;
}
require __DIR__ . '/includes/header.php';
$methodNames = ['cash' => 'Tiket pembayaran tunai', 'bank_transfer' => 'Transfer Bank'];
$statusNames = ['paid' => 'LUNAS', 'pending' => 'MENUNGGU PEMBAYARAN', 'rejected' => 'DITOLAK', 'failed' => 'GAGAL', 'expire' => 'KEDALUWARSA'];
?>
<section class="receipt-toolbar no-print"><div><h2>Kwitansi pembayaran</h2><p class="help">Gunakan tombol cetak untuk mencetak atau menyimpan sebagai PDF.</p></div><div style="display:flex;gap:8px;flex-wrap:wrap"><a class="btn btn-light" href="<?= APP_BASE ?>/payments.php">← Kembali</a><button class="btn" onclick="window.print()">⎙ Cetak / Simpan PDF</button></div></section>
<article class="receipt-paper">
    <header class="receipt-header"><div class="receipt-brand"><div class="receipt-logo"><?php if (app_school_logo_url()): ?><img src="<?= e(app_school_logo_url()) ?>" alt="Logo <?= e(app_school_name()) ?>"><?php else: ?><?= e(app_school_mark()) ?><?php endif; ?></div><div><h1><?= e(strtoupper(app_school_name())) ?></h1><p>Administrasi Keuangan · Bukti pembayaran resmi</p></div></div><div class="receipt-label"><span>KWITANSI</span><strong><?= e($payment['order_id']) ?></strong></div></header>
    <div class="receipt-rule"></div>
    <div class="receipt-status <?= $payment['status'] === 'paid' ? 'is-paid' : 'is-other' ?>"><span class="status-dot"></span><?= e($statusNames[$payment['status']] ?? strtoupper($payment['status'])) ?></div>
    <div class="receipt-amount"><small>TOTAL TRANSAKSI</small><strong><?= rupiah($payment['total_amount']) ?></strong><span>Terbilang: <?= e(ucwords(trim(angkaTerbilang((int)$payment['total_amount'])))) ?> rupiah</span></div>
    <div class="receipt-section-title">INFORMASI SANTRI</div>
    <div class="receipt-grid"><div><small>Nama santri</small><strong><?= e($payment['full_name']) ?></strong></div><div><small>Nomor induk</small><strong><?= e($payment['student_no']) ?></strong></div><div><small>Jenjang</small><strong><?= e($payment['class_level']) ?></strong></div><div><small>Username</small><strong><?= e($payment['username']) ?></strong></div></div>
    <div class="receipt-section-title">RINCIAN PEMBAYARAN</div>
    <table class="receipt-items"><thead><tr><th>Deskripsi</th><th>Periode</th><th class="align-right">Nominal</th></tr></thead><tbody><tr><td><strong><?= e($payment['category']) ?></strong><small>SPP dan biaya pendidikan</small></td><td><?= e(month_label($payment['billing_month'])) ?></td><td class="align-right"><?= rupiah($payment['total_amount']) ?></td></tr></tbody><tfoot><tr><td colspan="2">TOTAL</td><td class="align-right"><?= rupiah($payment['total_amount']) ?></td></tr></tfoot></table>
    <div class="receipt-grid receipt-meta"><div><small>Metode pembayaran</small><strong><?= e($methodNames[$payment['method']] ?? $payment['method']) ?></strong></div><div><small>Tanggal transaksi</small><strong><?= e(date('d/m/Y H:i', strtotime($payment['created_at']))) ?></strong></div><div><small>Waktu verifikasi</small><strong><?= $payment['verified_at'] ? e(date('d/m/Y H:i', strtotime($payment['verified_at']))) : '—' ?></strong></div><div><small>Petugas verifikasi</small><strong><?= e($payment['verifier_name'] ?: 'Sistem / belum diverifikasi') ?></strong></div></div>
    <?php if (!empty($payment['notes'])): ?><div class="receipt-note"><strong>Catatan</strong><p><?= e($payment['notes']) ?></p></div><?php endif; ?>
    <footer class="receipt-footer"><div><strong>Terima kasih</strong><p>Simpan kwitansi ini sebagai bukti administrasi pembayaran.</p><small>Dicetak pada <?= date('d/m/Y H:i') ?> · <?= e(app_school_name()) ?></small></div><div class="receipt-sign"><span>Petugas Keuangan</span><div></div><strong><?= e($payment['verifier_name'] ?: 'Administrasi Keuangan') ?></strong></div></footer>
</article>
<style>
.receipt-toolbar{display:flex;align-items:center;justify-content:space-between;gap:15px;margin-bottom:18px}.receipt-toolbar h2{margin:0;font:800 17px Manrope}.receipt-toolbar p{margin:5px 0 0}.receipt-paper{max-width:900px;margin:0 auto;background:#fff;border:1px solid #e2eae4;border-radius:18px;padding:42px 48px;box-shadow:0 18px 55px #193d2a12;color:#20362a}.receipt-header{display:flex;justify-content:space-between;align-items:center;gap:20px}.receipt-brand{display:flex;align-items:center;gap:14px}.receipt-logo{width:55px;height:55px;border-radius:16px;background:linear-gradient(135deg,#1aa56b,#075b3a);color:white;display:grid;place-items:center;font:800 18px Manrope;overflow:hidden}.receipt-logo img{width:100%;height:100%;object-fit:contain;background:#fff;padding:2px;border-radius:inherit}.receipt-brand h1{font:800 17px Manrope;margin:0;letter-spacing:.1px}.receipt-brand p{color:#7a8b80;margin:6px 0 0;font-size:11px}.receipt-label{text-align:right}.receipt-label span{display:block;font:800 11px Manrope;letter-spacing:2px;color:#16865b;margin-bottom:6px}.receipt-label strong{font-size:10px;color:#65776b;overflow-wrap:anywhere}.receipt-rule{height:3px;background:linear-gradient(90deg,#16865b,#b6e4cc,#eaf5ee);margin:25px 0}.receipt-status{display:inline-flex;align-items:center;gap:8px;padding:8px 12px;border-radius:30px;font-size:10px;font-weight:800;letter-spacing:.6px}.receipt-status.is-paid{background:#e7f8ee;color:#117648}.receipt-status.is-other{background:#fff5db;color:#8b6500}.status-dot{width:7px;height:7px;border-radius:50%;background:currentColor}.receipt-amount{margin:22px 0 27px;padding:23px;background:linear-gradient(120deg,#f0faf4,#f8fcf9);border:1px solid #dcefe3;border-radius:14px}.receipt-amount small,.receipt-grid small{display:block;color:#718378;font-size:10px;font-weight:700;letter-spacing:.6px;text-transform:uppercase;margin-bottom:8px}.receipt-amount strong{display:block;font:800 30px Manrope;color:#0c7548;letter-spacing:-.7px}.receipt-amount span{display:block;color:#728278;font-size:10px;margin-top:8px}.receipt-section-title{font:800 10px Manrope;letter-spacing:1.3px;color:#7a8a80;margin:24px 0 12px}.receipt-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px 28px}.receipt-grid strong{display:block;font-size:12px;overflow-wrap:anywhere}.receipt-items{width:100%;border-collapse:collapse;margin-top:5px;white-space:normal}.receipt-items th{background:#f5f9f6;color:#7a8a80;font-size:9px;padding:12px;text-align:left}.receipt-items td{padding:15px 12px;border-bottom:1px solid #eaf0eb;font-size:11px}.receipt-items td small{display:block;color:#829187;margin-top:5px}.receipt-items tfoot td{background:#f7fbf8;font-weight:800;color:#176f48}.align-right{text-align:right!important}.receipt-meta{margin-top:22px;padding-top:20px;border-top:1px dashed #d8e4dc}.receipt-note{background:#fafcfb;border-left:3px solid #16865b;padding:12px 15px;margin-top:22px;font-size:11px}.receipt-note p{margin:6px 0 0;color:#65776b}.receipt-footer{display:flex;justify-content:space-between;gap:25px;margin-top:36px;padding-top:22px;border-top:1px solid #e7eee9}.receipt-footer strong{font:800 13px Manrope}.receipt-footer p{font-size:10px;color:#718378;margin:7px 0}.receipt-footer small{font-size:9px;color:#9aa79f}.receipt-sign{text-align:center;width:180px;font-size:10px}.receipt-sign span{display:block;color:#718378}.receipt-sign div{height:48px;border-bottom:1px solid #cddbd1;margin-bottom:8px}.receipt-sign strong{font:700 10px 'DM Sans',sans-serif}
@media(max-width:650px){.receipt-paper{padding:24px 18px;border-radius:12px}.receipt-header{align-items:flex-start;flex-direction:column}.receipt-label{text-align:left}.receipt-brand h1{font-size:13px}.receipt-amount strong{font-size:25px}.receipt-grid{gap:15px}.receipt-footer{flex-direction:column}.receipt-sign{align-self:flex-end}.receipt-toolbar{align-items:flex-start;flex-direction:column}}
@media print{
@page{size:215mm 100mm landscape;margin:4mm}
html,body{width:207mm!important;height:92mm!important;margin:0!important;padding:0!important;background:#fff!important;font-size:7px!important;overflow:hidden!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.sidebar,.topbar,.footer,.no-print{display:none!important}
.app-shell,.main-area,.content{display:block!important;width:207mm!important;height:92mm!important;min-height:0!important;padding:0!important;margin:0!important;max-width:none!important;background:#fff!important;overflow:hidden!important}
.receipt-paper{box-sizing:border-box;width:207mm!important;height:92mm!important;max-width:none!important;border:1px solid #d7e2da;border-radius:0;box-shadow:none;padding:3mm 4mm!important;margin:0!important;overflow:hidden!important;display:block!important;color:#20362a!important}
.receipt-header{display:flex!important;justify-content:space-between!important;align-items:center!important;gap:4mm;break-inside:avoid}
.receipt-brand{gap:2mm}.receipt-logo{width:10mm;height:10mm;border-radius:2mm;font-size:10px}.receipt-brand h1{font-size:10px!important;line-height:1.2}.receipt-brand p{font-size:6px!important;margin:1mm 0 0!important}.receipt-label span{font-size:8px!important;margin-bottom:1mm!important}.receipt-label strong{font-size:7px!important}
.receipt-rule{height:1px!important;margin:2mm 0!important}
.receipt-status{font-size:6px!important;padding:1mm 2mm!important;gap:1mm}
.receipt-amount{padding:2mm 3mm!important;margin:2mm 0!important;border-radius:2mm;display:grid!important;grid-template-columns:30mm 55mm 1fr;align-items:center;gap:2mm}
.receipt-amount small{font-size:6px!important;margin:0!important}.receipt-amount strong{font-size:15px!important;line-height:1.1}.receipt-amount span{font-size:6px!important;margin:0!important}
.receipt-section-title{font-size:6px!important;letter-spacing:.5px!important;margin:2mm 0 1mm!important}
.receipt-grid{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:1mm 4mm!important}
.receipt-grid small{font-size:5.5px!important;margin-bottom:.5mm!important;letter-spacing:0!important}.receipt-grid strong{font-size:7px!important;line-height:1.15;overflow-wrap:anywhere}
.receipt-items{width:100%!important;margin-top:1mm!important;break-inside:avoid!important}.receipt-items th{font-size:6px!important;padding:1.2mm 2mm!important}.receipt-items td{font-size:7px!important;padding:1.2mm 2mm!important}.receipt-items td small{font-size:5.5px!important;margin-top:.5mm!important}
.receipt-meta{margin-top:2mm!important;padding-top:1.5mm!important;grid-template-columns:repeat(4,minmax(0,1fr))!important}
.receipt-note{font-size:6px!important;padding:1mm 2mm!important;margin-top:1mm!important}.receipt-note p{margin:0!important}
.receipt-footer{display:flex!important;justify-content:space-between!important;align-items:flex-end!important;gap:4mm;margin-top:2mm!important;padding-top:1.5mm!important;break-inside:avoid!important}.receipt-footer strong{font-size:7px!important}.receipt-footer p{font-size:5.5px!important;margin:1mm 0!important}.receipt-footer small{font-size:5px!important}.receipt-sign{width:38mm!important;font-size:6px!important}.receipt-sign div{height:5mm!important;margin-bottom:1mm!important}.receipt-sign strong{font-size:6px!important}
}
</style>
<?php require __DIR__ . '/includes/footer.php'; ?>
