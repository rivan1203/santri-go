<?php
require __DIR__ . '/config.php';
require_role('admin');
$from = trim((string)($_GET['from'] ?? ''));
$to = trim((string)($_GET['to'] ?? ''));
$status = $_GET['status'] ?? 'all';
$validDate = static function ($v) {
    $d = DateTime::createFromFormat('!Y-m-d', (string)$v);
    return $d && $d->format('Y-m-d') === $v;
};
if (($from !== '' && !$validDate($from)) || ($to !== '' && !$validDate($to)) || ($from !== '' && $to !== '' && $from > $to)) {
    $from = '';
    $to = '';
}
if (!in_array($status, ['pending', 'paid', 'rejected', 'failed', 'expire'], true)) $status = 'all';
$whereParts = [];
$params = [];
if ($from !== '') {
    $whereParts[] = 'DATE(p.created_at)>=?';
    $params[] = $from;
}
if ($to !== '') {
    $whereParts[] = 'DATE(p.created_at)<=?';
    $params[] = $to;
}
if ($status !== 'all') {
    $whereParts[] = 'p.status=?';
    $params[] = $status;
}
$where = $whereParts ? 'WHERE ' . implode(' AND ', $whereParts) : '';
$sql = "SELECT p.*,u.full_name,s.student_no,s.class_level,fc.name AS category,verifier.full_name AS verifier_name FROM payments p LEFT JOIN students s ON s.id=p.student_id LEFT JOIN users u ON u.id=s.user_id LEFT JOIN fee_categories fc ON fc.id=p.fee_category_id LEFT JOIN users verifier ON verifier.id=p.verified_by $where ORDER BY p.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
$statusLabels = ['all' => 'Semua status', 'pending' => 'Menunggu', 'paid' => 'Lunas', 'rejected' => 'Ditolak', 'failed' => 'Gagal', 'expire' => 'Kedaluwarsa'];
$methodLabels = ['cash' => 'Tunai', 'bank_transfer' => 'Transfer bank'];
$total = 0;
$paid = 0;
$paidCount = 0;
foreach ($rows as $r) {
    $total += (float)$r['total_amount'];
    if ($r['status'] === 'paid') {
        $paid += (float)$r['total_amount'];
        $paidCount++;
    }
}
$school = app_school_name();
$logo = app_school_logo_url();
function h($v)
{
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Laporan Transaksi - <?= h($school) ?></title>
    <style>
        :root {
            --navy: #142b4a;
            --blue: #244d7d;
            --line: #d7dee8;
            --muted: #64748b
        }

        * {
            box-sizing: border-box
        }

        body {
            font: 12px/1.45 Arial, Helvetica, sans-serif;
            color: #172334;
            margin: 0;
            background: #eef2f7
        }

        .toolbar {
            display: flex;
            gap: 10px;
            justify-content: center;
            padding: 18px
        }

        .btn {
            border: 0;
            border-radius: 6px;
            padding: 10px 17px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            font-size: 13px
        }

        .print {
            background: var(--navy);
            color: #fff
        }

        .back {
            background: #fff;
            color: var(--navy);
            border: 1px solid var(--line)
        }

        .paper {
            background: #fff;
            max-width: 1200px;
            margin: 0 auto 24px;
            padding: 24px 28px;
            box-shadow: 0 4px 24px #17233412
        }

        .head {
            display: flex;
            align-items: center;
            gap: 16px;
            border-bottom: 3px solid var(--navy);
            padding-bottom: 14px
        }

        .logo {
            width: 68px;
            height: 68px;
            object-fit: contain
        }

        .identity h1 {
            font-size: 19px;
            letter-spacing: .5px;
            margin: 0 0 4px;
            color: var(--navy)
        }

        .identity p {
            margin: 0;
            color: var(--muted)
        }

        .doc-title {
            text-align: center;
            margin: 18px 0 14px
        }

        .doc-title h2 {
            margin: 0;
            color: var(--navy);
            font-size: 17px;
            text-transform: uppercase;
            letter-spacing: .7px
        }

        .doc-title p {
            margin: 5px 0 0;
            color: var(--muted)
        }

        .meta {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 12px;
            padding: 10px 12px;
            background: #f5f7fa;
            border: 1px solid var(--line)
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
            margin: 12px 0 18px
        }

        .stat {
            border: 1px solid var(--line);
            border-top: 3px solid var(--blue);
            padding: 10px
        }

        .stat span {
            display: block;
            color: var(--muted);
            font-size: 10px;
            text-transform: uppercase
        }

        .stat strong {
            display: block;
            color: var(--navy);
            font-size: 15px;
            margin-top: 4px
        }

        table {
            width: 100%;
            border-collapse: collapse;
            table-layout: auto
        }

        thead {
            display: table-header-group
        }

        tr {
            break-inside: avoid
        }

        th {
            background: var(--navy);
            color: #fff;
            font-weight: 700;
            text-align: left
        }

        th,
        td {
            border: 1px solid var(--line);
            padding: 7px 6px;
            vertical-align: top
        }

        tbody tr:nth-child(even) {
            background: #f8fafc
        }

        .num,
        .money {
            text-align: right;
            white-space: nowrap
        }

        .center {
            text-align: center
        }

        .footer {
            display: flex;
            justify-content: space-between;
            border-top: 1px solid var(--line);
            margin-top: 18px;
            padding-top: 8px;
            color: var(--muted);
            font-size: 10px
        }

        .empty {
            text-align: center;
            padding: 25px;
            color: var(--muted)
        }

        @page {
            size: A4 landscape;
            margin: 10mm;

            @bottom-right {
                content: "Halaman " counter(page) " dari " counter(pages);
                font: 9px Arial;
                color: #64748b
            }
        }

        @media print {
            body {
                background: #fff;
                font-size: 9px
            }

            .toolbar {
                display: none
            }

            .paper {
                max-width: none;
                margin: 0;
                padding: 0;
                box-shadow: none
            }

            .head {
                break-inside: avoid
            }

            .logo {
                width: 52px;
                height: 52px
            }

            .identity h1 {
                font-size: 15px
            }

            .doc-title {
                margin: 12px 0
            }

            .doc-title h2 {
                font-size: 14px
            }

            .stats {
                gap: 6px;
                margin: 8px 0 12px
            }

            .stat {
                padding: 6px
            }

            .stat strong {
                font-size: 12px
            }

            th,
            td {
                padding: 5px 4px;
                font-size: 8px
            }

            .footer {
                margin-top: 10px
            }

            .meta {
                padding: 6px 8px
            }
        }
    </style>
</head>

<body>
    <div class="toolbar"><button class="btn print" onclick="window.print()">Cetak PDF</button><button class="btn back" onclick="history.length>1?history.back():location.href='reports.php'">Kembali</button></div>
    <main class="paper">
        <header class="head"><?php if ($logo): ?><img class="logo" src="<?= h($logo) ?>" alt="Logo pesantren"><?php endif; ?><div class="identity">
                <h1><?= h(mb_strtoupper($school, 'UTF-8')) ?></h1>
                <p>Dokumen Administrasi Pesantren · Sistem Santri Go</p>
            </div>
        </header>
        <div class="doc-title">
            <h2>Laporan Transaksi Pembayaran</h2>
            <p>Dokumen resmi administrasi keuangan</p>
        </div>
        <div class="meta"><span><b>Periode:</b> <?= h(($from || $to) ? (($from ? date('d/m/Y', strtotime($from)) : 'Awal') . ' – ' . ($to ? date('d/m/Y', strtotime($to)) : 'Sekarang')) : 'Semua tanggal') ?></span><span><b>Status:</b> <?= h($statusLabels[$status]) ?></span><span><b>Tanggal cetak:</b> <?= date('d/m/Y H:i') ?></span></div>
        <section class="stats">
            <div class="stat"><span>Total data transaksi</span><strong><?= number_format(count($rows), 0, ',', '.') ?></strong></div>
            <div class="stat"><span>Transaksi lunas</span><strong><?= number_format($paidCount, 0, ',', '.') ?></strong></div>
            <div class="stat"><span>Total nominal</span><strong>Rp <?= number_format($total, 0, ',', '.') ?></strong></div>
            <div class="stat"><span>Total nominal lunas</span><strong>Rp <?= number_format($paid, 0, ',', '.') ?></strong></div>
        </section>
        <table>
            <thead>
                <tr>
                    <th class="center">No.</th>
                    <th>Tanggal</th>
                    <th>Nama santri</th>
                    <th>No. induk</th>
                    <th>Jenjang</th>
                    <th>Tagihan</th>
                    <th>Periode</th>
                    <th>Metode</th>
                    <th>Status</th>
                    <th>Verifikator</th>
                    <th class="money">Nominal</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$rows): ?><tr>
                        <td colspan="11" class="empty">Tidak ada transaksi pada periode ini.</td>
                    </tr><?php else: foreach ($rows as $i => $r): ?><tr>
                            <td class="center"><?= $i + 1 ?></td>
                            <td><?= h(date('d/m/Y H:i', strtotime($r['created_at']))) ?></td>
                            <td><?= h($r['full_name'] ?: 'Data santri tidak tersedia') ?></td>
                            <td><?= h($r['student_no'] ?: '—') ?></td>
                            <td><?= h($r['class_level'] ?: '—') ?></td>
                            <td><?= h($r['category'] ?: '—') ?></td>
                            <td><?= h(date('m/Y', strtotime($r['billing_month']))) ?></td>
                            <td><?= h($methodLabels[$r['method']] ?? $r['method']) ?></td>
                            <td><?= h($statusLabels[$r['status']] ?? $r['status']) ?></td>
                            <td><?= h($r['verifier_name'] ?: '—') ?></td>
                            <td class="money">Rp <?= number_format((float)$r['total_amount'], 0, ',', '.') ?></td>
                        </tr><?php endforeach;
                        endif; ?>
            </tbody>
        </table>
        <footer class="footer"><span><?= h($school) ?> · Laporan administrasi keuangan</span><span>Dicetak melalui Santri Go</span></footer>
    </main>
    <script>
        window.addEventListener('load', () => setTimeout(() => window.print(), 350));
    </script>
</body>

</html>